"""Subpaquete de tests para lucy_voice."""
