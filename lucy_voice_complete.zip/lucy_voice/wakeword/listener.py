import sys
import os
import time
import logging
import asyncio
from lucy_voice.config import LucyConfig
from lucy_voice.pipeline.pipecat_graph import build_lucy_pipeline

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)8s | %(name)s:%(lineno)d - %(message)s",
    )

async def run_pipeline(config: LucyConfig):
    """
    Runs the Pipecat pipeline for continuous conversation.
    """
    pipeline = build_lucy_pipeline(config)
    
    # Get AudioInputNode (first processor)
    audio_input = pipeline.processors[0]
    
    logging.info("Starting Lucy Voice Pipeline (WakeWord -> VAD -> ASR -> LLM -> TTS)")
    
    # Start audio input stream
    await audio_input.start()
    
    try:
        # Run loop manually to pump frames
        await audio_input.run_loop()
    except asyncio.CancelledError:
        logging.info("Pipeline cancelled.")
    except Exception as e:
        logging.error(f"Pipeline error: {e}")
    finally:
        await audio_input.stop()
        logging.info("Pipeline stopped.")

def main():
    setup_logging()
    log = logging.getLogger("LucyListener")
    
    # Load config
    config_path = "config.yaml"
    if os.path.exists(config_path):
        config = LucyConfig.load_from_yaml(config_path)
        log.info(f"Config loaded from {config_path}")
    else:
        config = LucyConfig()
        log.info("Using default config")

    try:
        asyncio.run(run_pipeline(config))
    except KeyboardInterrupt:
        log.info("\nStopped by user (Ctrl+C).")
    except Exception as e:
        log.error(f"Error in main: {e}")

if __name__ == "__main__":
    main()

