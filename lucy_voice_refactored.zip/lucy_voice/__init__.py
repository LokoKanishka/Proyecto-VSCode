"""
Paquete `lucy_voice` – entorno de voz y herramientas de Lucy.
"""
# from . import lucy_tools  # Legacy import removed
